
export const SidebarTab = {
  PROCESS: 'PROCESS',
  ONEROUS: 'ONEROUS'
};
